/*const d = new Date();
document.write(d)
*/

/*const d = new Date("2022-03-25");
document.write(d)
*/

/*const d = new Date(2018, 11, 24, 10, 33, 30, 0);
document.write(d)
*/


/* toDateString()
const d = new Date();
document.write(d.toDateString());
*/

/*getMethod
const d = new Date("2021-03-25")
document.write(d.getFullYear());
*/

/*setMethod
const d = new Date();
d.setFullYear(2020, 11, 3);
document.write(d)
*/
